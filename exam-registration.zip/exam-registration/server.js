const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const { Parser } = require('json2csv');

const app = express();
const PORT = 3000;
const dataFile = path.join(__dirname, 'registrations.json');

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));


if (!fs.existsSync(dataFile)) {
  fs.writeFileSync(dataFile, JSON.stringify([]));
}

app.get('/', (req, res) => res.redirect('/register'));

app.get('/register', (req, res) => res.render('register'));

app.post('/register', (req, res) => {
  const { name, email, phone, subject, examDate } = req.body;

  if (!name || !email || !phone || !subject || !examDate) {
    return res.send("❌ Please fill all required details.");
  }

  const newRegistration = {
    name,
    email,
    phone,
    subject,
    examDate,
    dateRegistered: new Date().toLocaleString()
  };

  
  fs.readFile(dataFile, 'utf8', (err, data) => {
    if (err) return res.send(" Error in reading file.");
    let registrations = [];
    try {
      registrations = JSON.parse(data);
    } catch (e) {
      registrations = [];
    }

    registrations.push(newRegistration);

    fs.writeFile(dataFile, JSON.stringify(registrations, null, 2), (err) => {
      if (err) return res.send("⚠️ Error  in saving data.");
      res.render('success', { name });
    });
  });
});

app.get('/dashboard', (req, res) => {
  fs.readFile(dataFile, 'utf8', (err, data) => {
    if (err) return res.send("⚠️ Error loading dashboard.");
    let registrations = JSON.parse(data);

    const search = req.query.search ? req.query.search.toLowerCase() : '';
    if (search) {
      registrations = registrations.filter(r =>
        r.name.toLowerCase().includes(search) ||
        r.subject.toLowerCase().includes(search)
      );
    }

    res.render('dashboard', { registrations, search });
  });
});

app.get('/export', (req, res) => {
  fs.readFile(dataFile, 'utf8', (err, data) => {
    if (err) return res.send("⚠️ Error exporting data.");
    const registrations = JSON.parse(data);

    const fields = ['name', 'email', 'phone', 'subject', 'examDate', 'dateRegistered'];
    const parser = new Parser({ fields });
    const csv = parser.parse(registrations);

    res.header('Content-Type', 'text/csv');
    res.attachment('registrations.csv');
    res.send(csv);
  });
});

app.listen(PORT, () => {
  console.log(` Server running at http://localhost:${PORT}`);
});